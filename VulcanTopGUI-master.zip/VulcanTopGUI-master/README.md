# VulcanTopGUI
An addon for the Vulcan anticheat that opens a GUI of the top player violations

![The GUI](https://ajg0702.us/pics/Screen%20Shot%202022-02-11%20at%2010.58.13%20PM.png)
![The text on the heads](https://ajg0702.us/pics/Screen%20Shot%202022-02-11%20at%2011.03.30%20PM.png)

## How to use it

To open the gui, use `/topviolations` or `/topvl`. It requires the permission `vulcan.topgui`

When you click on a head, it runs `/vulcan clickalert %player%`. So basically it will be the same as if you clicked on an alert in chat.

You can click the items at the top to sort the different alert categories (total, combat, movement, player, autoclicker, timer, and scaffhold)

## Download

Download from [GitHub releases](https://github.com/ajgeiss0702/VulcanTopGUI/releases) (on the left or click the link)

## Support

If you want to ask questions, feel free to join [my discord](https://discord.gg/cqdBNbq)
